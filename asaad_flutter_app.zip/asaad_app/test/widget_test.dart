import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:asaad_digital_marketing/main.dart';

void main() {
  testWidgets('App launches correctly', (WidgetTester tester) async {
    // Verify the app starts with a splash screen
    expect(find.byType(MaterialApp), findsNothing);
  });
}
