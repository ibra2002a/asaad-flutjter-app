// ════════════════════════════════════════════════
//  admin_clients_screen.dart
// ════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/theme/app_theme.dart';
import '../../core/services/firebase_service.dart';

class AdminClientsScreen extends StatelessWidget {
  const AdminClientsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: const Text('إدارة العملاء',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800)),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseService().users.where('role', isEqualTo: 'client').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppTheme.primaryOrange));
          }
          final docs = snapshot.data?.docs ?? [];
          if (docs.isEmpty) {
            return const Center(
              child: Text('لا يوجد عملاء بعد', style: TextStyle(fontFamily: 'Cairo', color: AppTheme.grey, fontSize: 16)),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final data = docs[i].data() as Map<String, dynamic>;
              return Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: isDark ? AppTheme.blackCard : Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: AppTheme.primaryOrange.withOpacity(0.1),
                      child: Text(
                        (data['name'] ?? 'م')[0].toUpperCase(),
                        style: const TextStyle(fontFamily: 'Cairo', color: AppTheme.primaryOrange, fontWeight: FontWeight.w800, fontSize: 18),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(data['name'] ?? '', style: const TextStyle(fontFamily: 'Cairo', fontSize: 15, fontWeight: FontWeight.w700)),
                          Text(data['email'] ?? '', style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppTheme.grey)),
                          Text(data['phone'] ?? '', style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppTheme.grey)),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: AppTheme.success.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Text('نشط', style: TextStyle(fontFamily: 'Cairo', fontSize: 11, color: AppTheme.success, fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(height: 4),
                        Text('${data['totalOrders'] ?? 0} طلب', style: const TextStyle(fontFamily: 'Cairo', fontSize: 11, color: AppTheme.grey)),
                      ],
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// ════════════════════════════════════════════════
//  admin_orders_screen.dart
// ════════════════════════════════════════════════
class AdminOrdersScreen extends StatefulWidget {
  const AdminOrdersScreen({super.key});
  @override
  State<AdminOrdersScreen> createState() => _AdminOrdersScreenState();
}

class _AdminOrdersScreenState extends State<AdminOrdersScreen> {
  String _filter = 'all';

  Color _statusColor(String s) {
    switch (s) {
      case 'new': return AppTheme.info;
      case 'in_progress': return AppTheme.warning;
      case 'review': return const Color(0xFF9C27B0);
      case 'completed': return AppTheme.success;
      case 'cancelled': return AppTheme.error;
      default: return AppTheme.grey;
    }
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'new': return 'جديد';
      case 'in_progress': return 'قيد التنفيذ';
      case 'review': return 'مراجعة';
      case 'completed': return 'مكتمل';
      case 'cancelled': return 'ملغي';
      default: return s;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: const Text('إدارة الطلبات',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800)),
      ),
      body: Column(
        children: [
          // Filter chips
          SizedBox(
            height: 50,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              children: [
                for (final f in ['all', 'new', 'in_progress', 'review', 'completed', 'cancelled'])
                  GestureDetector(
                    onTap: () => setState(() => _filter = f),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: _filter == f ? AppTheme.primaryOrange : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: _filter == f ? AppTheme.primaryOrange : AppTheme.grey.withOpacity(0.3)),
                      ),
                      child: Text(
                        f == 'all' ? 'الكل' : _statusLabel(f),
                        style: TextStyle(fontFamily: 'Cairo', fontSize: 12, fontWeight: FontWeight.w600, color: _filter == f ? Colors.white : AppTheme.grey),
                      ),
                    ),
                  ),
              ],
            ),
          ),

          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseService().getAllOrders(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: AppTheme.primaryOrange));
                final all = snapshot.data!.docs;
                final filtered = _filter == 'all' ? all : all.where((d) => (d.data() as Map)['status'] == _filter).toList();

                if (filtered.isEmpty) {
                  return const Center(child: Text('لا توجد طلبات', style: TextStyle(fontFamily: 'Cairo', color: AppTheme.grey)));
                }

                return ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (_, i) {
                    final data = filtered[i].data() as Map<String, dynamic>;
                    final status = data['status'] ?? 'new';
                    final color = _statusColor(status);

                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: isDark ? AppTheme.blackCard : Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: color.withOpacity(0.2)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(data['serviceName'] ?? '',
                                    style: const TextStyle(fontFamily: 'Cairo', fontSize: 14, fontWeight: FontWeight.w700)),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                                child: Text(_statusLabel(status), style: TextStyle(fontFamily: 'Cairo', fontSize: 11, color: color, fontWeight: FontWeight.w700)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text('السعر: ${data['price']?.toString() ?? 0} د.ع',
                              style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppTheme.grey)),
                          const SizedBox(height: 8),
                          // Progress slider for admin
                          Row(
                            children: [
                              const Text('التقدم: ', style: TextStyle(fontFamily: 'Cairo', fontSize: 12)),
                              Expanded(
                                child: SliderTheme(
                                  data: SliderThemeData(
                                    activeTrackColor: color,
                                    thumbColor: color,
                                    inactiveTrackColor: color.withOpacity(0.2),
                                    trackHeight: 4,
                                    thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
                                  ),
                                  child: Slider(
                                    value: ((data['progress'] ?? 0) as int).toDouble(),
                                    min: 0,
                                    max: 100,
                                    divisions: 10,
                                    label: '${data['progress']}%',
                                    onChanged: (v) async {
                                      String newStatus = status;
                                      if (v == 100) newStatus = 'completed';
                                      else if (v > 0 && v < 80) newStatus = 'in_progress';
                                      else if (v >= 80) newStatus = 'review';
                                      await FirebaseService().updateOrderStatus(
                                        orderId: data['orderId'] ?? filtered[i].id,
                                        status: newStatus,
                                        progress: v.toInt(),
                                      );
                                    },
                                  ),
                                ),
                              ),
                              Text('${data['progress'] ?? 0}%', style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: color, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════
//  admin_employees_screen.dart
// ════════════════════════════════════════════════
class AdminEmployeesScreen extends StatelessWidget {
  const AdminEmployeesScreen({super.key});

  final _employees = const [
    {'name': 'علي حسن', 'role': 'مصمم جرافيك', 'orders': 12, 'rating': 4.8},
    {'name': 'سارة محمد', 'role': 'مدير سوشيال ميديا', 'orders': 20, 'rating': 4.9},
    {'name': 'أحمد كريم', 'role': 'مصور احترافي', 'orders': 8, 'rating': 4.7},
    {'name': 'نور عبدالله', 'role': 'مطور مواقع', 'orders': 5, 'rating': 5.0},
    {'name': 'محمد طارق', 'role': 'مونتير فيديو', 'orders': 15, 'rating': 4.6},
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: const Text('إدارة الموظفين',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add_outlined, color: AppTheme.primaryOrange),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _employees.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) {
          final emp = _employees[i];
          return Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isDark ? AppTheme.blackCard : Colors.white,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AppTheme.primaryOrange, AppTheme.primaryOrangeDark]),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    (emp['name'] as String)[0],
                    style: const TextStyle(fontFamily: 'Cairo', color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(emp['name'] as String, style: const TextStyle(fontFamily: 'Cairo', fontSize: 15, fontWeight: FontWeight.w700)),
                      Text(emp['role'] as String, style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppTheme.grey)),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(Icons.assignment_outlined, size: 12, color: AppTheme.primaryOrange),
                          const SizedBox(width: 3),
                          Text('${emp['orders']} طلب', style: const TextStyle(fontFamily: 'Cairo', fontSize: 11, color: AppTheme.grey)),
                          const SizedBox(width: 10),
                          const Icon(Icons.star_rounded, size: 12, color: AppTheme.warning),
                          const SizedBox(width: 3),
                          Text('${emp['rating']}', style: const TextStyle(fontFamily: 'Cairo', fontSize: 11, color: AppTheme.grey)),
                        ],
                      ),
                    ],
                  ),
                ),
                PopupMenuButton(
                  icon: const Icon(Icons.more_vert, color: AppTheme.grey),
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'edit', child: Text('تعديل', style: TextStyle(fontFamily: 'Cairo'))),
                    const PopupMenuItem(value: 'delete', child: Text('حذف', style: TextStyle(fontFamily: 'Cairo', color: AppTheme.error))),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ════════════════════════════════════════════════
//  admin_reports_screen.dart
// ════════════════════════════════════════════════
class AdminReportsScreen extends StatelessWidget {
  const AdminReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final monthlyData = [
      {'month': 'يناير', 'revenue': 1200000, 'orders': 8},
      {'month': 'فبراير', 'revenue': 1800000, 'orders': 12},
      {'month': 'مارس', 'revenue': 2400000, 'orders': 16},
      {'month': 'أبريل', 'revenue': 2100000, 'orders': 14},
      {'month': 'مايو', 'revenue': 3200000, 'orders': 21},
      {'month': 'يونيو', 'revenue': 2800000, 'orders': 19},
    ];

    final maxRevenue = monthlyData.map((m) => m['revenue'] as int).reduce((a, b) => a > b ? a : b);

    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: const Text('التقارير والإحصائيات',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            icon: const Icon(Icons.download_outlined, color: AppTheme.primaryOrange),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Summary cards
            Row(
              children: [
                _ReportCard(label: 'إجمالي الإيرادات', value: '13.5M', unit: 'د.ع', icon: Icons.trending_up_rounded, color: AppTheme.success),
                const SizedBox(width: 12),
                _ReportCard(label: 'متوسط الطلب', value: '149K', unit: 'د.ع', icon: Icons.bar_chart_rounded, color: AppTheme.info),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _ReportCard(label: 'معدل الإكمال', value: '94%', unit: '', icon: Icons.check_circle_outline, color: AppTheme.primaryOrange),
                const SizedBox(width: 12),
                _ReportCard(label: 'رضا العملاء', value: '4.8', unit: '/ 5', icon: Icons.star_rounded, color: AppTheme.warning),
              ],
            ),

            const SizedBox(height: 24),

            // Revenue chart
            const Text('الإيرادات الشهرية',
                style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isDark ? AppTheme.blackCard : Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 160,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: monthlyData.map((m) {
                        final height = ((m['revenue'] as int) / maxRevenue) * 140;
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              '${((m['revenue'] as int) / 1000000).toStringAsFixed(1)}M',
                              style: const TextStyle(fontFamily: 'Cairo', fontSize: 9, color: AppTheme.grey),
                            ),
                            const SizedBox(height: 4),
                            Container(
                              width: 32,
                              height: height,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [AppTheme.primaryOrange, AppTheme.primaryOrangeDark],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: monthlyData.map((m) => Text(
                      (m['month'] as String).substring(0, 3),
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 10, color: AppTheme.grey),
                    )).toList(),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Services performance
            const Text('أداء الخدمات',
                style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),

            ...[
              {'name': 'إدارة السوشيال ميديا', 'percent': 0.85, 'orders': 42},
              {'name': 'تصميم الهويات البصرية', 'percent': 0.72, 'orders': 35},
              {'name': 'الحملات الممولة', 'percent': 0.68, 'orders': 33},
              {'name': 'تصميم المواقع', 'percent': 0.55, 'orders': 27},
              {'name': 'إنتاج الفيديو', 'percent': 0.48, 'orders': 24},
            ].map((s) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: isDark ? AppTheme.blackCard : Colors.white,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(s['name'] as String, style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, fontWeight: FontWeight.w600)),
                      Text('${s['orders']} طلب', style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: AppTheme.grey)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: s['percent'] as double,
                      backgroundColor: AppTheme.primaryOrange.withOpacity(0.1),
                      valueColor: const AlwaysStoppedAnimation(AppTheme.primaryOrange),
                      minHeight: 8,
                    ),
                  ),
                ],
              ),
            )),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}

class _ReportCard extends StatelessWidget {
  final String label, value, unit;
  final IconData icon;
  final Color color;

  const _ReportCard({required this.label, required this.value, required this.unit, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isDark ? AppTheme.blackCard : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontFamily: 'Cairo', fontSize: 10, color: AppTheme.grey)),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text(value, style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w800, color: color)),
                      if (unit.isNotEmpty) Text(' $unit', style: const TextStyle(fontFamily: 'Cairo', fontSize: 10, color: AppTheme.grey)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
