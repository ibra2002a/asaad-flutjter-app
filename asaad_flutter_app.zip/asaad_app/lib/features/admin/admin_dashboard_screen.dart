import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/routes/app_router.dart';
import '../../core/services/firebase_service.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  Map<String, dynamic>? _stats;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final stats = await FirebaseService().getAdminStats();
      if (mounted) setState(() { _stats = stats; _isLoading = false; });
    } catch (e) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        automaticallyImplyLeading: false,
        title: const Text(
          'لوحة التحكم',
          style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => Navigator.pushNamed(context, AppRouter.notifications),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseService().signOut();
              if (mounted) Navigator.pushReplacementNamed(context, AppRouter.login);
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadStats,
        color: AppTheme.primaryOrange,
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(color: AppTheme.primaryOrange))
            : SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Welcome
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [AppTheme.primaryOrange, AppTheme.primaryOrangeDark],
                        ),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.admin_panel_settings,
                              color: Colors.white, size: 40),
                          SizedBox(width: 16),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'مرحباً، المدير العام',
                                style: TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                'اصعد للإعلانات والتسويق الرقمي',
                                style: TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 12,
                                  color: Colors.white70,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    // Stats grid
                    const Text(
                      'الإحصائيات',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 12),
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      childAspectRatio: 1.4,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      children: [
                        _StatCard(
                          label: 'إجمالي العملاء',
                          value: '${_stats?['totalClients'] ?? 0}',
                          icon: Icons.people_outline,
                          color: const Color(0xFF4CAF50),
                        ),
                        _StatCard(
                          label: 'إجمالي الطلبات',
                          value: '${_stats?['totalOrders'] ?? 0}',
                          icon: Icons.assignment_outlined,
                          color: const Color(0xFF2196F3),
                        ),
                        _StatCard(
                          label: 'مشاريع مكتملة',
                          value: '${_stats?['completedOrders'] ?? 0}',
                          icon: Icons.check_circle_outline,
                          color: AppTheme.primaryOrange,
                        ),
                        _StatCard(
                          label: 'الإيرادات الكلية',
                          value:
                              '${((_stats?['totalRevenue'] ?? 0) / 1000).toStringAsFixed(0)}K د.ع',
                          icon: Icons.monetization_on_outlined,
                          color: const Color(0xFF9C27B0),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Quick actions
                    const Text(
                      'الإجراءات السريعة',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 12),
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 2,
                      childAspectRatio: 1.8,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      children: [
                        _ActionCard(
                          label: 'إدارة العملاء',
                          icon: Icons.people,
                          onTap: () =>
                              Navigator.pushNamed(context, AppRouter.adminClients),
                        ),
                        _ActionCard(
                          label: 'إدارة الطلبات',
                          icon: Icons.list_alt,
                          onTap: () =>
                              Navigator.pushNamed(context, AppRouter.adminOrders),
                        ),
                        _ActionCard(
                          label: 'إدارة الموظفين',
                          icon: Icons.badge,
                          onTap: () =>
                              Navigator.pushNamed(context, AppRouter.adminEmployees),
                        ),
                        _ActionCard(
                          label: 'التقارير',
                          icon: Icons.bar_chart,
                          onTap: () =>
                              Navigator.pushNamed(context, AppRouter.adminReports),
                        ),
                        _ActionCard(
                          label: 'إرسال إشعار',
                          icon: Icons.notifications_active,
                          onTap: () => _showNotificationDialog(),
                        ),
                        _ActionCard(
                          label: 'معرض الأعمال',
                          icon: Icons.photo_library,
                          onTap: () =>
                              Navigator.pushNamed(context, AppRouter.portfolio),
                        ),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Recent orders
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'آخر الطلبات',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        TextButton(
                          onPressed: () =>
                              Navigator.pushNamed(context, AppRouter.adminOrders),
                          child: const Text(
                            'عرض الكل',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              color: AppTheme.primaryOrange,
                            ),
                          ),
                        ),
                      ],
                    ),
                    ..._buildRecentOrders(isDark),

                    const SizedBox(height: 40),
                  ],
                ),
              ),
      ),
    );
  }

  List<Widget> _buildRecentOrders(bool isDark) {
    final orders = [
      {'name': 'أحمد محمد', 'service': 'تصميم هوية بصرية', 'status': 'قيد التنفيذ', 'statusColor': AppTheme.warning},
      {'name': 'سارة علي', 'service': 'إدارة سوشيال ميديا', 'status': 'جديد', 'statusColor': AppTheme.info},
      {'name': 'محمد حسين', 'service': 'تصوير احترافي', 'status': 'مكتمل', 'statusColor': AppTheme.success},
    ];

    return orders.map((order) => Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.blackCard : Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundColor: AppTheme.primaryOrange.withOpacity(0.1),
                child: Text(
                  (order['name'] as String)[0],
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    color: AppTheme.primaryOrange,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    order['name'] as String,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                    ),
                  ),
                  Text(
                    order['service'] as String,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 12,
                      color: AppTheme.grey,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: (order['statusColor'] as Color).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              order['status'] as String,
              style: TextStyle(
                fontFamily: 'Cairo',
                fontSize: 11,
                color: order['statusColor'] as Color,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    )).toList();
  }

  void _showNotificationDialog() {
    showDialog(
      context: context,
      builder: (ctx) {
        final titleController = TextEditingController();
        final bodyController = TextEditingController();
        return AlertDialog(
          title: const Text('إرسال إشعار', style: TextStyle(fontFamily: 'Cairo')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                decoration: const InputDecoration(
                  labelText: 'عنوان الإشعار',
                  labelStyle: TextStyle(fontFamily: 'Cairo'),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bodyController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'نص الإشعار',
                  labelStyle: TextStyle(fontFamily: 'Cairo'),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء', style: TextStyle(fontFamily: 'Cairo')),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx),
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryOrange),
              child: const Text('إرسال', style: TextStyle(fontFamily: 'Cairo', color: Colors.white)),
            ),
          ],
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.blackCard : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(icon, color: color, size: 28),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  color: AppTheme.grey,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _ActionCard({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? AppTheme.blackCard : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppTheme.primaryOrange.withOpacity(0.2),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppTheme.primaryOrange, size: 22),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                fontFamily: 'Cairo',
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
