// ════════════════════════════════════════════════
//  FILE: lib/features/auth/register_screen.dart
// ════════════════════════════════════════════════
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/routes/app_router.dart';
import '../../core/services/firebase_service.dart';
import '../../core/widgets/custom_button.dart';
import '../../core/widgets/custom_text_field.dart';
import '../../core/widgets/loading_overlay.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscure = true, _obscureC = true, _isLoading = false;

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) return;
    if (_passCtrl.text != _confirmCtrl.text) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('كلمتا المرور غير متطابقتين', style: TextStyle(fontFamily: 'Cairo')), backgroundColor: AppTheme.error));
      return;
    }
    setState(() => _isLoading = true);
    try {
      final cred = await FirebaseService().registerWithEmail(_emailCtrl.text.trim(), _passCtrl.text);
      await FirebaseService().createUserProfile(uid: cred.user!.uid, name: _nameCtrl.text.trim(), email: _emailCtrl.text.trim(), phone: _phoneCtrl.text.trim(), role: 'client');
      if (mounted) Navigator.pushReplacementNamed(context, AppRouter.main);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString(), style: const TextStyle(fontFamily: 'Cairo')), backgroundColor: AppTheme.error));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() { _nameCtrl.dispose(); _emailCtrl.dispose(); _phoneCtrl.dispose(); _passCtrl.dispose(); _confirmCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return LoadingOverlay(
      isLoading: _isLoading,
      child: Scaffold(
        backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
        appBar: AppBar(backgroundColor: isDark ? AppTheme.black : AppTheme.white, title: const Text('إنشاء حساب جديد', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800))),
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const SizedBox(height: 8),
              CustomTextField(controller: _nameCtrl, label: 'الاسم الكامل', prefixIcon: Icons.person_outline, validator: (v) => v!.isEmpty ? 'الاسم مطلوب' : null),
              const SizedBox(height: 14),
              CustomTextField(controller: _emailCtrl, label: 'البريد الإلكتروني', prefixIcon: Icons.email_outlined, keyboardType: TextInputType.emailAddress, validator: (v) => v!.isEmpty ? 'البريد مطلوب' : null),
              const SizedBox(height: 14),
              CustomTextField(controller: _phoneCtrl, label: 'رقم الهاتف', prefixIcon: Icons.phone_outlined, keyboardType: TextInputType.phone, validator: (v) => v!.isEmpty ? 'الهاتف مطلوب' : null),
              const SizedBox(height: 14),
              CustomTextField(controller: _passCtrl, label: 'كلمة المرور', prefixIcon: Icons.lock_outline, obscureText: _obscure,
                suffixIcon: IconButton(icon: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined, color: AppTheme.grey), onPressed: () => setState(() => _obscure = !_obscure)),
                validator: (v) => (v?.length ?? 0) < 6 ? 'كلمة المرور قصيرة' : null),
              const SizedBox(height: 14),
              CustomTextField(controller: _confirmCtrl, label: 'تأكيد كلمة المرور', prefixIcon: Icons.lock_outline, obscureText: _obscureC,
                suffixIcon: IconButton(icon: Icon(_obscureC ? Icons.visibility_outlined : Icons.visibility_off_outlined, color: AppTheme.grey), onPressed: () => setState(() => _obscureC = !_obscureC)),
                validator: (v) => v!.isEmpty ? 'التأكيد مطلوب' : null),
              const SizedBox(height: 24),
              CustomButton(label: 'إنشاء الحساب', onPressed: _register),
              const SizedBox(height: 16),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('لديك حساب بالفعل؟ ', style: TextStyle(fontFamily: 'Cairo', color: AppTheme.grey)),
                GestureDetector(onTap: () => Navigator.pop(context), child: const Text('تسجيل الدخول', style: TextStyle(fontFamily: 'Cairo', color: AppTheme.primaryOrange, fontWeight: FontWeight.w700))),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}
