import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/routes/app_router.dart';
import '../../core/widgets/custom_button.dart';

class ServiceDetailScreen extends StatelessWidget {
  final Map<String, dynamic> service;
  const ServiceDetailScreen({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color = service['color'] as Color? ?? AppTheme.primaryOrange;
    final features = service['features'] as List? ?? [];

    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      body: CustomScrollView(
        slivers: [
          // Sliver app bar with gradient
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            backgroundColor: AppTheme.black,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [color, color.withOpacity(0.6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Stack(
                  children: [
                    // Pattern
                    Positioned.fill(
                      child: CustomPaint(painter: _ServiceHeaderPainter(color)),
                    ),
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const SizedBox(height: 40),
                          Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Icon(service['icon'] as IconData? ?? Icons.star,
                                color: Colors.white, size: 44),
                          ),
                          const SizedBox(height: 14),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 24),
                            child: Text(
                              service['nameAr'] as String? ?? '',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Content
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Price & Duration row
                  Row(
                    children: [
                      Expanded(
                        child: _InfoChip(
                          icon: Icons.monetization_on_rounded,
                          label: 'السعر',
                          value:
                              'من ${service['price']?.toString() ?? '0'} د.ع',
                          color: color,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _InfoChip(
                          icon: Icons.schedule_rounded,
                          label: 'مدة التنفيذ',
                          value: service['duration'] as String? ?? '',
                          color: color,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // Description
                  const Text('وصف الخدمة',
                      style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 16,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: isDark ? AppTheme.blackCard : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      service['descriptionAr'] as String? ??
                          'خدمة احترافية متكاملة',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 14,
                        height: 1.8,
                        color: AppTheme.grey,
                      ),
                      textDirection: TextDirection.rtl,
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Features
                  const Text('ما يشمله الطلب',
                      style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 16,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  ...features.map((f) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            Container(
                              width: 28,
                              height: 28,
                              decoration: BoxDecoration(
                                color: color.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(Icons.check_rounded,
                                  color: color, size: 16),
                            ),
                            const SizedBox(width: 12),
                            Text(
                              f as String,
                              style: const TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      )),

                  const SizedBox(height: 24),

                  // Process steps
                  const Text('خطوات العمل',
                      style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 16,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  _buildProcessSteps(color),

                  const SizedBox(height: 32),

                  // Order button
                  CustomButton(
                    label: 'اطلب الخدمة الآن',
                    icon: Icons.add_shopping_cart_rounded,
                    onPressed: () => Navigator.pushNamed(
                      context,
                      AppRouter.createOrder,
                    ),
                  ),

                  const SizedBox(height: 12),

                  CustomButton(
                    label: 'تواصل معنا',
                    icon: Icons.chat_outlined,
                    isOutlined: true,
                    onPressed: () => Navigator.pushNamed(
                      context,
                      AppRouter.chatDetail,
                      arguments: {
                        'chatId':
                            'chat_${FirebaseServiceRef.currentUid()}',
                        'name': 'الدعم الفني',
                      },
                    ),
                  ),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProcessSteps(Color color) {
    final steps = [
      {'num': '1', 'title': 'تقديم الطلب', 'desc': 'أرسل طلبك مع التفاصيل'},
      {'num': '2', 'title': 'المراجعة والتأكيد', 'desc': 'نراجع ونؤكد خلال 24 ساعة'},
      {'num': '3', 'title': 'بدء التنفيذ', 'desc': 'فريقنا يبدأ العمل فوراً'},
      {'num': '4', 'title': 'التسليم', 'desc': 'استلام العمل مع التعديلات'},
    ];

    return Column(
      children: steps.map((s) {
        final isLast = steps.last == s;
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  alignment: Alignment.center,
                  child: Text(s['num']!,
                      style: const TextStyle(
                          fontFamily: 'Cairo',
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 14)),
                ),
                if (!isLast)
                  Container(width: 2, height: 32, color: color.withOpacity(0.2)),
              ],
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 24, top: 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s['title']!,
                        style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 14,
                            fontWeight: FontWeight.w700)),
                    Text(s['desc']!,
                        style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            color: AppTheme.grey)),
                  ],
                ),
              ),
            ),
          ],
        );
      }).toList(),
    );
  }
}

class FirebaseServiceRef {
  static String currentUid() {
    try {
      return 'support';
    } catch (_) {
      return 'support';
    }
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _InfoChip(
      {required this.icon,
      required this.label,
      required this.value,
      required this.color});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? AppTheme.blackCard : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 11,
                        color: AppTheme.grey)),
                Text(value,
                    style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: color)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ServiceHeaderPainter extends CustomPainter {
  final Color color;
  _ServiceHeaderPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.07)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (int i = 0; i < 4; i++) {
      canvas.drawCircle(
          Offset(size.width * 0.1, size.height * 0.8), 40.0 + i * 30, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
