import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/routes/app_router.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  String _searchQuery = '';
  String _selectedCategory = 'all';

  final _categories = [
    {'id': 'all', 'label': 'الكل'},
    {'id': 'social', 'label': 'سوشيال'},
    {'id': 'design', 'label': 'تصميم'},
    {'id': 'media', 'label': 'ميديا'},
    {'id': 'marketing', 'label': 'تسويق'},
    {'id': 'tech', 'label': 'تقنية'},
  ];

  final _services = [
    {
      'id': 'social_management',
      'nameAr': 'إدارة صفحات التواصل الاجتماعي',
      'descriptionAr': 'إدارة احترافية ومتكاملة لجميع منصات التواصل الاجتماعي بما فيها فيسبوك، انستغرام، تيك توك وتويتر.',
      'icon': Icons.people_alt_rounded,
      'price': 250000,
      'duration': '30 يوم',
      'category': 'social',
      'color': const Color(0xFF4CAF50),
      'features': ['جدولة المنشورات', 'الرد على التعليقات', 'تحليل الأداء', 'تقارير شهرية'],
    },
    {
      'id': 'post_design',
      'nameAr': 'تصميم منشورات السوشيال ميديا',
      'descriptionAr': 'تصميم منشورات إبداعية واحترافية تتناسب مع هوية علامتك التجارية وتجذب الجمهور المستهدف.',
      'icon': Icons.brush_rounded,
      'price': 50000,
      'duration': '3-5 أيام',
      'category': 'design',
      'color': const Color(0xFF2196F3),
      'features': ['تصميم بوستات', 'ستوري وريلز', 'قوالب احترافية', 'ملفات مفتوحة'],
    },
    {
      'id': 'brand_identity',
      'nameAr': 'تصميم الهويات البصرية',
      'descriptionAr': 'هوية بصرية متكاملة ومميزة تعكس قيم علامتك التجارية وتترك انطباعاً احترافياً دائماً.',
      'icon': Icons.diamond_rounded,
      'price': 500000,
      'duration': '7-14 يوم',
      'category': 'design',
      'color': const Color(0xFF9C27B0),
      'features': ['شعار رئيسي', 'بطاقة أعمال', 'ورقة رسمية', 'دليل الهوية'],
    },
    {
      'id': 'logo_design',
      'nameAr': 'تصميم الشعارات',
      'descriptionAr': 'تصميم شعار فريد ومميز يعكس هوية علامتك التجارية بشكل احترافي وإبداعي.',
      'icon': Icons.auto_awesome_rounded,
      'price': 150000,
      'duration': '5-7 أيام',
      'category': 'design',
      'color': const Color(0xFFFF9800),
      'features': ['3 تصاميم مقترحة', 'تعديلات غير محدودة', 'ملفات PNG/SVG/PDF', 'حقوق ملكية كاملة'],
    },
    {
      'id': 'video_production',
      'nameAr': 'إنتاج الفيديو والمونتاج',
      'descriptionAr': 'إنتاج فيديوهات إعلانية احترافية وموشن جرافيك لترويج خدماتك ومنتجاتك.',
      'icon': Icons.video_camera_back_rounded,
      'price': 300000,
      'duration': '7-10 أيام',
      'category': 'media',
      'color': const Color(0xFFF44336),
      'features': ['سيناريو احترافي', 'مونتاج متقدم', 'موسيقى تصويرية', 'تصدير بجودة 4K'],
    },
    {
      'id': 'photography',
      'nameAr': 'التصوير الاحترافي',
      'descriptionAr': 'جلسات تصوير احترافية لمنتجاتك وأعمالك مع معالجة احترافية للصور.',
      'icon': Icons.camera_alt_rounded,
      'price': 200000,
      'duration': '1-3 أيام',
      'category': 'media',
      'color': const Color(0xFF607D8B),
      'features': ['تصوير بمعدات احترافية', 'معالجة وريتش', '50+ صورة', 'تسليم خلال 48 ساعة'],
    },
    {
      'id': 'paid_ads',
      'nameAr': 'الحملات الإعلانية الممولة',
      'descriptionAr': 'إدارة حملات إعلانية ممولة احترافية على فيسبوك، انستغرام وجوجل لزيادة مبيعاتك.',
      'icon': Icons.campaign_rounded,
      'price': 400000,
      'duration': '30 يوم',
      'category': 'marketing',
      'color': AppTheme.primaryOrange,
      'features': ['استهداف دقيق', 'تحسين مستمر', 'تقارير أسبوعية', 'ROI مضمون'],
    },
    {
      'id': 'web_design',
      'nameAr': 'تصميم المواقع الإلكترونية',
      'descriptionAr': 'تصميم وتطوير مواقع إلكترونية احترافية وسريعة ومتجاوبة مع جميع الأجهزة.',
      'icon': Icons.web_rounded,
      'price': 1000000,
      'duration': '30-60 يوم',
      'category': 'tech',
      'color': const Color(0xFF00BCD4),
      'features': ['تصميم عصري', 'متجاوب مع الموبايل', 'لوحة تحكم', 'SEO محسّن'],
    },
    {
      'id': 'app_development',
      'nameAr': 'تطوير تطبيقات الهاتف',
      'descriptionAr': 'تطوير تطبيقات Android و iOS احترافية بأحدث التقنيات وأفضل تجربة مستخدم.',
      'icon': Icons.phone_android_rounded,
      'price': 3000000,
      'duration': '60-120 يوم',
      'category': 'tech',
      'color': const Color(0xFF3F51B5),
      'features': ['Android + iOS', 'Clean Architecture', 'Firebase Integration', 'دعم مستمر'],
    },
    {
      'id': 'seo',
      'nameAr': 'تحسين محركات البحث SEO',
      'descriptionAr': 'تحسين ظهور موقعك الإلكتروني في نتائج محركات البحث لزيادة الزوار العضويين.',
      'icon': Icons.search_rounded,
      'price': 350000,
      'duration': '30-90 يوم',
      'category': 'marketing',
      'color': const Color(0xFF795548),
      'features': ['تحليل الكلمات المفتاحية', 'تحسين المحتوى', 'بناء الروابط', 'تقارير شهرية'],
    },
  ];

  List<Map<String, dynamic>> get _filteredServices {
    return _services.where((s) {
      final matchesCategory =
          _selectedCategory == 'all' || s['category'] == _selectedCategory;
      final matchesSearch = _searchQuery.isEmpty ||
          (s['nameAr'] as String)
              .toLowerCase()
              .contains(_searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: const Text('خدماتنا',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800)),
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _searchQuery = v),
              textDirection: TextDirection.rtl,
              decoration: InputDecoration(
                hintText: 'ابحث عن خدمة...',
                hintStyle: const TextStyle(fontFamily: 'Cairo'),
                prefixIcon: const Icon(Icons.search, color: AppTheme.grey),
                filled: true,
                fillColor: isDark ? AppTheme.blackCard : Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),

          // Category filter
          SizedBox(
            height: 46,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final cat = _categories[i];
                final isSelected = _selectedCategory == cat['id'];
                return GestureDetector(
                  onTap: () => setState(() => _selectedCategory = cat['id']!),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? AppTheme.primaryOrange : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected ? AppTheme.primaryOrange : AppTheme.grey.withOpacity(0.3),
                      ),
                    ),
                    child: Text(
                      cat['label']!,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: isSelected ? Colors.white : AppTheme.grey,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 8),

          // Services list
          Expanded(
            child: _filteredServices.isEmpty
                ? const Center(
                    child: Text('لا توجد خدمات',
                        style: TextStyle(fontFamily: 'Cairo', color: AppTheme.grey)))
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: _filteredServices.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, i) => _ServiceCard(
                      service: _filteredServices[i],
                      onTap: () => Navigator.pushNamed(
                        context,
                        AppRouter.serviceDetail,
                        arguments: _filteredServices[i],
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final Map<String, dynamic> service;
  final VoidCallback onTap;

  const _ServiceCard({required this.service, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color = service['color'] as Color;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? AppTheme.blackCard : Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(service['icon'] as IconData, color: color, size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      service['nameAr'] as String,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.monetization_on_outlined,
                            size: 13, color: color),
                        const SizedBox(width: 3),
                        Text(
                          'من ${service['price'].toString()} د.ع',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            color: color,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Icon(Icons.schedule_outlined,
                            size: 13, color: AppTheme.grey),
                        const SizedBox(width: 3),
                        Text(
                          service['duration'] as String,
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            color: AppTheme.grey,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 4,
                      runSpacing: 4,
                      children: ((service['features'] as List).take(3))
                          .map((f) => Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(
                                  color: color.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  f as String,
                                  style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 10,
                                    color: color,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ))
                          .toList(),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios,
                  size: 14, color: AppTheme.grey),
            ],
          ),
        ),
      ),
    );
  }
}
