// ════════════════════════════════════════════════
//  profile_screen.dart
// ════════════════════════════════════════════════
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/routes/app_router.dart';
import '../../core/services/firebase_service.dart';
import '../../core/providers/theme_provider.dart';
import '../../core/providers/language_provider.dart';
import 'package:provider/provider.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _profile;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = FirebaseService().currentUser?.uid;
    if (uid != null) {
      final p = await FirebaseService().getUserProfile(uid);
      if (mounted) setState(() => _profile = p);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final themeProvider = context.read<ThemeProvider>();
    final langProvider = context.read<LanguageProvider>();

    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: const Text('حسابي', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800)),
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Avatar
            Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(colors: [AppTheme.primaryOrange, AppTheme.primaryOrangeDark]),
                boxShadow: [BoxShadow(color: AppTheme.primaryOrange.withOpacity(0.3), blurRadius: 16)],
              ),
              child: const Icon(Icons.person_rounded, color: Colors.white, size: 50),
            ),
            const SizedBox(height: 12),
            Text(_profile?['name'] ?? 'المستخدم', style: const TextStyle(fontFamily: 'Cairo', fontSize: 20, fontWeight: FontWeight.w800)),
            Text(_profile?['email'] ?? '', style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, color: AppTheme.grey)),
            const SizedBox(height: 24),

            // Stats row
            Row(children: [
              _ProfileStat(label: 'الطلبات', value: '${_profile?['totalOrders'] ?? 0}'),
              const SizedBox(width: 12),
              _ProfileStat(label: 'المكتملة', value: '${_profile?['completedOrders'] ?? 0}'),
              const SizedBox(width: 12),
              const _ProfileStat(label: 'التقييم', value: '5 ⭐'),
            ]),

            const SizedBox(height: 24),

            // Settings
            _SettingTile(icon: Icons.dark_mode_outlined, label: 'الوضع الليلي',
              trailing: Switch(
                value: isDark,
                onChanged: (_) => themeProvider.toggleTheme(),
                activeColor: AppTheme.primaryOrange,
              ),
            ),
            _SettingTile(icon: Icons.language_outlined, label: 'اللغة',
              trailing: TextButton(
                onPressed: () => langProvider.toggleLanguage(),
                child: Text(
                  langProvider.locale.languageCode == 'ar' ? 'English' : 'عربي',
                  style: const TextStyle(fontFamily: 'Cairo', color: AppTheme.primaryOrange),
                ),
              ),
            ),
            _SettingTile(icon: Icons.auto_awesome_outlined, label: 'Asaad AI',
              onTap: () => Navigator.pushNamed(context, AppRouter.aiAssistant),
            ),
            _SettingTile(icon: Icons.photo_library_outlined, label: 'معرض الأعمال',
              onTap: () => Navigator.pushNamed(context, AppRouter.portfolio),
            ),
            _SettingTile(icon: Icons.notifications_outlined, label: 'الإشعارات',
              onTap: () => Navigator.pushNamed(context, AppRouter.notifications),
            ),
            _SettingTile(icon: Icons.help_outline, label: 'الدعم الفني',
              onTap: () => Navigator.pushNamed(context, AppRouter.chatDetail, arguments: {'chatId': 'chat_support', 'name': 'الدعم الفني'}),
            ),
            _SettingTile(
              icon: Icons.logout_rounded,
              label: 'تسجيل الخروج',
              color: AppTheme.error,
              onTap: () async {
                await FirebaseService().signOut();
                if (context.mounted) Navigator.pushReplacementNamed(context, AppRouter.login);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileStat extends StatelessWidget {
  final String label, value;
  const _ProfileStat({required this.label, required this.value});
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isDark ? AppTheme.blackCard : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.primaryOrange.withOpacity(0.2)),
        ),
        child: Column(children: [
          Text(value, style: const TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.primaryOrange)),
          Text(label, style: const TextStyle(fontFamily: 'Cairo', fontSize: 11, color: AppTheme.grey)),
        ]),
      ),
    );
  }
}

class _SettingTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color? color;
  const _SettingTile({required this.icon, required this.label, this.trailing, this.onTap, this.color});
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final c = color ?? (isDark ? Colors.white : Colors.black87);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: isDark ? AppTheme.blackCard : Colors.white,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          Icon(icon, color: color ?? AppTheme.primaryOrange, size: 22),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: TextStyle(fontFamily: 'Cairo', fontSize: 14, fontWeight: FontWeight.w600, color: c))),
          trailing ?? const Icon(Icons.arrow_forward_ios, size: 14, color: AppTheme.grey),
        ]),
      ),
    );
  }
}
