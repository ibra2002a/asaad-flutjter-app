import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../core/theme/app_theme.dart';
import '../../core/routes/app_router.dart';
import '../../core/services/firebase_service.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  String _formatTime(Timestamp? ts) {
    if (ts == null) return '';
    final dt = ts.toDate();
    final now = DateTime.now();
    if (dt.day == now.day) {
      return '${dt.hour}:${dt.minute.toString().padLeft(2, '0')}';
    }
    return '${dt.day}/${dt.month}';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final uid = FirebaseService().currentUser?.uid ?? '';
    final chatId = 'chat_$uid';

    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: const Text('المحادثات',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w800)),
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              textDirection: TextDirection.rtl,
              decoration: InputDecoration(
                hintText: 'ابحث في المحادثات...',
                hintStyle:
                    const TextStyle(fontFamily: 'Cairo', color: AppTheme.grey),
                prefixIcon: const Icon(Icons.search, color: AppTheme.grey),
                filled: true,
                fillColor: isDark ? AppTheme.blackCard : Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),

          // Support chat card (always visible)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GestureDetector(
              onTap: () => Navigator.pushNamed(
                context,
                AppRouter.chatDetail,
                arguments: {
                  'chatId': chatId,
                  'name': 'الدعم الفني - اصعد',
                },
              ),
              child: StreamBuilder<DocumentSnapshot>(
                stream: FirebaseService().chats.doc(chatId).snapshots(),
                builder: (context, snapshot) {
                  final chatData =
                      snapshot.data?.data() as Map<String, dynamic>? ?? {};
                  final lastMsg = chatData['lastMessage'] ?? 'ابدأ المحادثة...';
                  final unread = (chatData['unreadCount'] ?? 0) as int;
                  final lastTime = chatData['lastMessageTime'] as Timestamp?;

                  return Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isDark ? AppTheme.blackCard : Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                          color: AppTheme.primaryOrange.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        // Avatar with online indicator
                        Stack(
                          children: [
                            Container(
                              width: 52,
                              height: 52,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [
                                    AppTheme.primaryOrange,
                                    AppTheme.primaryOrangeDark
                                  ],
                                ),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.support_agent_rounded,
                                  color: Colors.white, size: 28),
                            ),
                            Positioned(
                              bottom: 2,
                              right: 2,
                              child: Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: AppTheme.success,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: isDark
                                          ? AppTheme.blackCard
                                          : Colors.white,
                                      width: 2),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  const Text(
                                    'الدعم الفني - اصعد',
                                    style: TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700),
                                  ),
                                  Text(
                                    _formatTime(lastTime),
                                    style: const TextStyle(
                                        fontFamily: 'Cairo',
                                        fontSize: 11,
                                        color: AppTheme.grey),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Expanded(
                                    child: Text(
                                      lastMsg,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          fontFamily: 'Cairo',
                                          fontSize: 12,
                                          color: AppTheme.grey),
                                    ),
                                  ),
                                  if (unread > 0)
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 7, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: AppTheme.primaryOrange,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        '$unread',
                                        style: const TextStyle(
                                            fontFamily: 'Cairo',
                                            fontSize: 11,
                                            color: Colors.white,
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),

          const SizedBox(height: 16),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                const Text('محادثات المشاريع',
                    style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 15,
                        fontWeight: FontWeight.w700)),
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryOrange.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text('قريباً',
                      style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 11,
                          color: AppTheme.primaryOrange,
                          fontWeight: FontWeight.w700)),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.chat_bubble_outline_rounded,
                      size: 60, color: AppTheme.grey.withOpacity(0.3)),
                  const SizedBox(height: 12),
                  const Text('لا توجد محادثات أخرى',
                      style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 14,
                          color: AppTheme.grey)),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(
          context,
          AppRouter.chatDetail,
          arguments: {
            'chatId': chatId,
            'name': 'الدعم الفني - اصعد',
          },
        ),
        backgroundColor: AppTheme.primaryOrange,
        child: const Icon(Icons.chat_rounded, color: Colors.white),
      ),
    );
  }
}
