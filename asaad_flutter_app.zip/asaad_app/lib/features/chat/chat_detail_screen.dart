import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../../core/theme/app_theme.dart';
import '../../core/services/firebase_service.dart';

class ChatDetailScreen extends StatefulWidget {
  final Map<String, dynamic> chatData;
  const ChatDetailScreen({super.key, required this.chatData});

  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final _messageController = TextEditingController();
  final _scrollController = ScrollController();
  final _firebase = FirebaseService();
  final _recorder = AudioRecorder();
  bool _isRecording = false;
  bool _isSending = false;

  String get _chatId => widget.chatData['chatId'] ?? '';
  String get _chatName => widget.chatData['name'] ?? 'الدعم الفني';

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    _recorder.dispose();
    super.dispose();
  }

  Future<void> _sendTextMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;
    _messageController.clear();

    final uid = _firebase.currentUser!.uid;
    final profile = await _firebase.getUserProfile(uid);

    await _firebase.sendMessage(
      chatId: _chatId,
      senderId: uid,
      senderName: profile?['name'] ?? 'مستخدم',
      content: text,
      type: 'text',
    );
    _scrollToBottom();
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    setState(() => _isSending = true);
    try {
      final uid = _firebase.currentUser!.uid;
      final url = await _firebase.uploadFile(
        File(picked.path),
        'chats/$_chatId/${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      final profile = await _firebase.getUserProfile(uid);
      await _firebase.sendMessage(
        chatId: _chatId,
        senderId: uid,
        senderName: profile?['name'] ?? 'مستخدم',
        content: '📷 صورة',
        type: 'image',
        fileUrl: url,
      );
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _toggleRecording() async {
    if (_isRecording) {
      final path = await _recorder.stop();
      setState(() => _isRecording = false);
      if (path != null) {
        final uid = _firebase.currentUser!.uid;
        final url = await _firebase.uploadFile(
          File(path),
          'chats/$_chatId/${DateTime.now().millisecondsSinceEpoch}.m4a',
        );
        final profile = await _firebase.getUserProfile(uid);
        await _firebase.sendMessage(
          chatId: _chatId,
          senderId: uid,
          senderName: profile?['name'] ?? 'مستخدم',
          content: '🎤 رسالة صوتية',
          type: 'audio',
          fileUrl: url,
        );
      }
    } else {
      final hasPermission = await _recorder.hasPermission();
      if (hasPermission) {
        final dir = await getTemporaryDirectory();
        await _recorder.start(
          RecordConfig(),
          path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.m4a',
        );
        setState(() => _isRecording = true);
      }
    }
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final uid = _firebase.currentUser?.uid ?? '';

    return Scaffold(
      backgroundColor: isDark ? AppTheme.black : AppTheme.whiteOff,
      appBar: AppBar(
        backgroundColor: isDark ? AppTheme.black : AppTheme.white,
        title: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppTheme.primaryOrange, AppTheme.primaryOrangeDark],
                ),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.support_agent, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _chatName,
                  style: const TextStyle(
                      fontFamily: 'Cairo', fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const Text(
                  'متصل الآن 🟢',
                  style: TextStyle(
                      fontFamily: 'Cairo', fontSize: 11, color: AppTheme.success),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.call_outlined), onPressed: () {}),
          IconButton(icon: const Icon(Icons.more_vert), onPressed: () {}),
        ],
      ),
      body: Column(
        children: [
          // Messages list
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _firebase.getChatMessages(_chatId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(
                      child: CircularProgressIndicator(color: AppTheme.primaryOrange));
                }
                final msgs = snapshot.data!.docs;
                if (msgs.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.chat_bubble_outline,
                            size: 64, color: AppTheme.grey.withOpacity(0.3)),
                        const SizedBox(height: 16),
                        const Text(
                          'ابدأ المحادثة مع فريق الدعم',
                          style: TextStyle(
                              fontFamily: 'Cairo', fontSize: 14, color: AppTheme.grey),
                        ),
                      ],
                    ),
                  );
                }

                WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());

                return ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final msgData = msgs[i].data() as Map<String, dynamic>;
                    final isMe = msgData['senderId'] == uid;
                    final type = msgData['type'] ?? 'text';

                    // Show date separator
                    bool showDate = i == 0;
                    if (i > 0) {
                      final prev = msgs[i - 1].data() as Map<String, dynamic>;
                      final prevTime =
                          (prev['createdAt'] as Timestamp?)?.toDate();
                      final currTime =
                          (msgData['createdAt'] as Timestamp?)?.toDate();
                      if (prevTime != null && currTime != null) {
                        showDate = currTime.day != prevTime.day;
                      }
                    }

                    return Column(
                      children: [
                        if (showDate)
                          _DateSeparator(
                              timestamp: msgData['createdAt'] as Timestamp?),
                        _ChatBubble(
                          msgData: msgData,
                          isMe: isMe,
                          type: type,
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),

          // Input area
          Container(
            padding: EdgeInsets.only(
              left: 12,
              right: 12,
              top: 8,
              bottom: MediaQuery.of(context).viewInsets.bottom + 8,
            ),
            decoration: BoxDecoration(
              color: isDark ? AppTheme.blackCard : Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Row(
              children: [
                // Attachment
                IconButton(
                  icon: const Icon(Icons.attach_file_rounded,
                      color: AppTheme.grey),
                  onPressed: _sendImage,
                ),

                // Text field
                Expanded(
                  child: Container(
                    constraints: const BoxConstraints(maxHeight: 120),
                    decoration: BoxDecoration(
                      color: isDark ? AppTheme.black : AppTheme.whiteOff,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: TextField(
                      controller: _messageController,
                      maxLines: null,
                      textDirection: TextDirection.rtl,
                      decoration: const InputDecoration(
                        hintText: 'اكتب رسالة...',
                        hintStyle: TextStyle(fontFamily: 'Cairo', fontSize: 14),
                        border: InputBorder.none,
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 14),
                      onChanged: (v) => setState(() {}),
                    ),
                  ),
                ),

                const SizedBox(width: 8),

                // Send / Voice button
                GestureDetector(
                  onTap: _messageController.text.trim().isNotEmpty
                      ? _sendTextMessage
                      : _toggleRecording,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: _isRecording
                            ? [AppTheme.error, AppTheme.error]
                            : [AppTheme.primaryOrange, AppTheme.primaryOrangeDark],
                      ),
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: (_isRecording
                                  ? AppTheme.error
                                  : AppTheme.primaryOrange)
                              .withOpacity(0.4),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: Icon(
                      _messageController.text.trim().isNotEmpty
                          ? Icons.send_rounded
                          : (_isRecording ? Icons.stop_rounded : Icons.mic_rounded),
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ChatBubble extends StatelessWidget {
  final Map<String, dynamic> msgData;
  final bool isMe;
  final String type;

  const _ChatBubble({required this.msgData, required this.isMe, required this.type});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final time = (msgData['createdAt'] as Timestamp?)?.toDate();
    final timeStr = time != null ? '${time.hour}:${time.minute.toString().padLeft(2, '0')}' : '';

    return Align(
      alignment: isMe ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
        margin: const EdgeInsets.symmetric(vertical: 3),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.start : CrossAxisAlignment.end,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: isMe
                    ? const LinearGradient(
                        colors: [AppTheme.primaryOrange, AppTheme.primaryOrangeDark])
                    : null,
                color: isMe ? null : (isDark ? AppTheme.blackCard : Colors.white),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(18),
                  topRight: const Radius.circular(18),
                  bottomLeft: Radius.circular(isMe ? 4 : 18),
                  bottomRight: Radius.circular(isMe ? 18 : 4),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: type == 'image' && msgData['fileUrl'] != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.network(
                        msgData['fileUrl'],
                        width: 200,
                        height: 160,
                        fit: BoxFit.cover,
                      ),
                    )
                  : type == 'audio'
                      ? Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.play_circle_filled,
                                color: isMe ? Colors.white : AppTheme.primaryOrange,
                                size: 28),
                            const SizedBox(width: 8),
                            Text(
                              'رسالة صوتية',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 13,
                                color: isMe ? Colors.white : null,
                              ),
                            ),
                          ],
                        )
                      : Text(
                          msgData['content'] ?? '',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 14,
                            color: isMe ? Colors.white : null,
                            height: 1.4,
                          ),
                          textDirection: TextDirection.rtl,
                        ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 2, left: 4, right: 4),
              child: Text(
                timeStr,
                style: const TextStyle(
                    fontFamily: 'Cairo', fontSize: 10, color: AppTheme.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DateSeparator extends StatelessWidget {
  final Timestamp? timestamp;
  const _DateSeparator({this.timestamp});

  @override
  Widget build(BuildContext context) {
    if (timestamp == null) return const SizedBox.shrink();
    final dt = timestamp!.toDate();
    final now = DateTime.now();
    String label;
    if (dt.day == now.day && dt.month == now.month) {
      label = 'اليوم';
    } else if (dt.day == now.day - 1) {
      label = 'أمس';
    } else {
      label = '${dt.day}/${dt.month}/${dt.year}';
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          const Expanded(child: Divider()),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              label,
              style: const TextStyle(
                  fontFamily: 'Cairo', fontSize: 11, color: AppTheme.grey),
            ),
          ),
          const Expanded(child: Divider()),
        ],
      ),
    );
  }
}
