import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageProvider extends ChangeNotifier {
  static const _key = 'language';
  final SharedPreferences _prefs;
  Locale _locale;

  LanguageProvider(this._prefs)
      : _locale = Locale(
            _prefs.getString(_key) ?? 'ar',
            _prefs.getString(_key) == 'en' ? 'US' : 'IQ');

  Locale get locale => _locale;
  bool get isArabic => _locale.languageCode == 'ar';

  void toggleLanguage() {
    _locale = _locale.languageCode == 'ar'
        ? const Locale('en', 'US')
        : const Locale('ar', 'IQ');
    _prefs.setString(_key, _locale.languageCode);
    notifyListeners();
  }

  void setLanguage(String code) {
    _locale = code == 'ar' ? const Locale('ar', 'IQ') : const Locale('en', 'US');
    _prefs.setString(_key, code);
    notifyListeners();
  }
}
