import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  static const Map<String, Map<String, String>> _localizedStrings = {
    'ar': {
      'app_name': 'اصعد للإعلانات والتسويق الرقمي',
      'home': 'الرئيسية',
      'services': 'الخدمات',
      'orders': 'الطلبات',
      'chats': 'المحادثات',
      'profile': 'حسابي',
      'login': 'تسجيل الدخول',
      'register': 'إنشاء حساب',
      'logout': 'تسجيل الخروج',
      'email': 'البريد الإلكتروني',
      'password': 'كلمة المرور',
      'phone': 'رقم الهاتف',
      'name': 'الاسم الكامل',
      'submit': 'إرسال',
      'cancel': 'إلغاء',
      'save': 'حفظ',
      'delete': 'حذف',
      'edit': 'تعديل',
      'search': 'بحث',
      'loading': 'جاري التحميل...',
      'error': 'حدث خطأ',
      'success': 'تم بنجاح',
      'new_order': 'طلب جديد',
      'order_status': 'حالة الطلب',
      'payment': 'الدفع',
      'notifications': 'الإشعارات',
      'portfolio': 'معرض الأعمال',
      'ai_assistant': 'المساعد الذكي',
      'admin_dashboard': 'لوحة التحكم',
      'clients': 'العملاء',
      'employees': 'الموظفين',
      'reports': 'التقارير',
      'settings': 'الإعدادات',
      'dark_mode': 'الوضع الليلي',
      'language': 'اللغة',
      'arabic': 'العربية',
      'english': 'الإنجليزية',
    },
    'en': {
      'app_name': 'Asaad Digital Marketing',
      'home': 'Home',
      'services': 'Services',
      'orders': 'Orders',
      'chats': 'Chats',
      'profile': 'Profile',
      'login': 'Login',
      'register': 'Register',
      'logout': 'Logout',
      'email': 'Email',
      'password': 'Password',
      'phone': 'Phone Number',
      'name': 'Full Name',
      'submit': 'Submit',
      'cancel': 'Cancel',
      'save': 'Save',
      'delete': 'Delete',
      'edit': 'Edit',
      'search': 'Search',
      'loading': 'Loading...',
      'error': 'An error occurred',
      'success': 'Success',
      'new_order': 'New Order',
      'order_status': 'Order Status',
      'payment': 'Payment',
      'notifications': 'Notifications',
      'portfolio': 'Portfolio',
      'ai_assistant': 'AI Assistant',
      'admin_dashboard': 'Dashboard',
      'clients': 'Clients',
      'employees': 'Employees',
      'reports': 'Reports',
      'settings': 'Settings',
      'dark_mode': 'Dark Mode',
      'language': 'Language',
      'arabic': 'Arabic',
      'english': 'English',
    },
  };

  String translate(String key) {
    return _localizedStrings[locale.languageCode]?[key] ?? key;
  }

  String get appName => translate('app_name');
  String get home => translate('home');
  String get services => translate('services');
  String get orders => translate('orders');
  String get chats => translate('chats');
  String get profile => translate('profile');
  String get login => translate('login');
  String get register => translate('register');
  String get logout => translate('logout');
  String get email => translate('email');
  String get password => translate('password');
  String get phone => translate('phone');
  String get name => translate('name');
  String get submit => translate('submit');
  String get cancel => translate('cancel');
  String get save => translate('save');
  String get loading => translate('loading');
  String get error => translate('error');
  String get success => translate('success');
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      ['ar', 'en'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async =>
      AppLocalizations(locale);

  @override
  bool shouldReload(covariant LocalizationsDelegate<AppLocalizations> old) =>
      false;
}
