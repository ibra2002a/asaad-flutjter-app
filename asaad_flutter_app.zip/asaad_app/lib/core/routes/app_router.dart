import 'package:flutter/material.dart';

import '../../features/splash/splash_screen.dart';
import '../../features/auth/login_screen.dart';
import '../../features/auth/register_screen.dart';
import '../../features/auth/forgot_password_screen.dart';
import '../../features/home/home_screen.dart';
import '../../features/services/services_screen.dart';
import '../../features/services/service_detail_screen.dart';
import '../../features/orders/orders_screen.dart';
import '../../features/orders/order_detail_screen.dart';
import '../../features/orders/create_order_screen.dart';
import '../../features/chat/chat_list_screen.dart';
import '../../features/chat/chat_detail_screen.dart';
import '../../features/portfolio/portfolio_screen.dart';
import '../../features/payment/payment_screen.dart';
import '../../features/notifications/notifications_screen.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/ai_assistant/ai_assistant_screen.dart';
import '../../features/admin/admin_dashboard_screen.dart';
import '../../features/admin/admin_clients_screen.dart';
import '../../features/admin/admin_orders_screen.dart';
import '../../features/admin/admin_employees_screen.dart';
import '../../features/admin/admin_reports_screen.dart';
import '../../features/main/main_nav_screen.dart';

class AppRouter {
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String main = '/main';
  static const String home = '/home';
  static const String services = '/services';
  static const String serviceDetail = '/service-detail';
  static const String orders = '/orders';
  static const String orderDetail = '/order-detail';
  static const String createOrder = '/create-order';
  static const String chatList = '/chat-list';
  static const String chatDetail = '/chat-detail';
  static const String portfolio = '/portfolio';
  static const String payment = '/payment';
  static const String notifications = '/notifications';
  static const String profile = '/profile';
  static const String aiAssistant = '/ai-assistant';
  static const String adminDashboard = '/admin-dashboard';
  static const String adminClients = '/admin-clients';
  static const String adminOrders = '/admin-orders';
  static const String adminEmployees = '/admin-employees';
  static const String adminReports = '/admin-reports';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return _buildRoute(const SplashScreen(), settings);
      case login:
        return _buildRoute(const LoginScreen(), settings);
      case register:
        return _buildRoute(const RegisterScreen(), settings);
      case forgotPassword:
        return _buildRoute(const ForgotPasswordScreen(), settings);
      case main:
        return _buildRoute(const MainNavScreen(), settings);
      case services:
        return _buildRoute(const ServicesScreen(), settings);
      case serviceDetail:
        return _buildRoute(
          ServiceDetailScreen(service: settings.arguments as Map<String, dynamic>),
          settings,
        );
      case orders:
        return _buildRoute(const OrdersScreen(), settings);
      case orderDetail:
        return _buildRoute(
          OrderDetailScreen(orderId: settings.arguments as String),
          settings,
        );
      case createOrder:
        return _buildRoute(const CreateOrderScreen(), settings);
      case chatList:
        return _buildRoute(const ChatListScreen(), settings);
      case chatDetail:
        return _buildRoute(
          ChatDetailScreen(chatData: settings.arguments as Map<String, dynamic>),
          settings,
        );
      case portfolio:
        return _buildRoute(const PortfolioScreen(), settings);
      case payment:
        return _buildRoute(
          PaymentScreen(orderData: settings.arguments as Map<String, dynamic>),
          settings,
        );
      case notifications:
        return _buildRoute(const NotificationsScreen(), settings);
      case profile:
        return _buildRoute(const ProfileScreen(), settings);
      case aiAssistant:
        return _buildRoute(const AiAssistantScreen(), settings);
      case adminDashboard:
        return _buildRoute(const AdminDashboardScreen(), settings);
      case adminClients:
        return _buildRoute(const AdminClientsScreen(), settings);
      case adminOrders:
        return _buildRoute(const AdminOrdersScreen(), settings);
      case adminEmployees:
        return _buildRoute(const AdminEmployeesScreen(), settings);
      case adminReports:
        return _buildRoute(const AdminReportsScreen(), settings);
      default:
        return _buildRoute(const SplashScreen(), settings);
    }
  }

  static MaterialPageRoute _buildRoute(Widget widget, RouteSettings settings) {
    return MaterialPageRoute(
      builder: (_) => widget,
      settings: settings,
    );
  }
}
